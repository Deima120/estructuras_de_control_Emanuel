using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CurdNativoVentas.Data;
using CurdNativoVentas.Models;

namespace CurdNativoVentas.Controllers
{
    public class VentasController : Controller
    {
        private readonly ApplicationDbContext _context;

        public VentasController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Ventas
        public async Task<IActionResult> Index()
        {
            var ventas = await _context.Ventas
                .Include(v => v.Cliente)
                .Include(v => v.DetalleVentas)
                    .ThenInclude(d => d.Producto)
                .ToListAsync();
            return View(ventas);
        }

        // GET: Ventas/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var venta = await _context.Ventas
                .Include(v => v.Cliente)
                .Include(v => v.DetalleVentas)
                    .ThenInclude(d => d.Producto)
                .FirstOrDefaultAsync(m => m.VentaId == id);

            if (venta == null)
            {
                return NotFound();
            }

            return View(venta);
        }

        // GET: Ventas/Create
        public IActionResult Create()
        {
            ViewData["ClienteId"] = new SelectList(_context.Clientes, "ClienteId", "NombreCompleto");
            ViewData["Productos"] = new SelectList(_context.Productos, "ProductoId", "Nombre");
            return View();
        }

        // POST: Ventas/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("VentaId,ClienteId,FechaVenta,DetalleVentas")] Venta venta)
        {
            // Filtrar detalles vacíos o inválidos
            if (venta.DetalleVentas != null)
            {
                venta.DetalleVentas = venta.DetalleVentas.Where(d => d.ProductoId > 0 && d.Cantidad > 0).ToList();
            }

            // Validar que haya al menos un detalle
            if (venta.DetalleVentas == null || !venta.DetalleVentas.Any())
            {
                ModelState.AddModelError("", "Debe agregar al menos un producto a la venta.");
            }

            if (ModelState.IsValid && venta.DetalleVentas != null && venta.DetalleVentas.Any())
            {
                // Calcular el total de la venta y validar stock
                decimal total = 0;
                foreach (var detalle in venta.DetalleVentas)
                {
                    var producto = await _context.Productos.FindAsync(detalle.ProductoId);
                    if (producto != null)
                    {
                        // Validar stock disponible
                        if (producto.Stock < detalle.Cantidad)
                        {
                            ModelState.AddModelError("", $"Stock insuficiente para el producto {producto.Nombre}. Stock disponible: {producto.Stock}");
                            ViewData["ClienteId"] = new SelectList(_context.Clientes, "ClienteId", "NombreCompleto", venta.ClienteId);
                            ViewData["Productos"] = new SelectList(_context.Productos, "ProductoId", "Nombre");
                            return View(venta);
                        }

                        detalle.PrecioUnitario = producto.Precio;
                        detalle.Subtotal = detalle.Cantidad * detalle.PrecioUnitario;
                        total += detalle.Subtotal;

                        // Actualizar stock
                        producto.Stock -= detalle.Cantidad;
                        _context.Update(producto);
                    }
                }
                venta.Total = total;

                _context.Add(venta);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            ViewData["ClienteId"] = new SelectList(_context.Clientes, "ClienteId", "NombreCompleto", venta.ClienteId);
            ViewData["Productos"] = new SelectList(_context.Productos, "ProductoId", "Nombre");
            return View(venta);
        }

        // GET: Ventas/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var venta = await _context.Ventas
                .Include(v => v.DetalleVentas)
                .FirstOrDefaultAsync(v => v.VentaId == id);

            if (venta == null)
            {
                return NotFound();
            }

            ViewData["ClienteId"] = new SelectList(_context.Clientes, "ClienteId", "NombreCompleto", venta.ClienteId);
            ViewData["Productos"] = new SelectList(_context.Productos, "ProductoId", "Nombre");
            return View(venta);
        }

        // POST: Ventas/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("VentaId,ClienteId,FechaVenta,DetalleVentas")] Venta venta)
        {
            if (id != venta.VentaId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    // Eliminar detalles anteriores
                    var detallesAnteriores = await _context.DetalleVentas
                        .Where(d => d.VentaId == id)
                        .ToListAsync();

                    // Restaurar stock
                    foreach (var detalle in detallesAnteriores)
                    {
                        var producto = await _context.Productos.FindAsync(detalle.ProductoId);
                        if (producto != null)
                        {
                            producto.Stock += detalle.Cantidad;
                            _context.Update(producto);
                        }
                    }

                    _context.DetalleVentas.RemoveRange(detallesAnteriores);

                    // Calcular nuevo total
                    decimal total = 0;
                    foreach (var detalle in venta.DetalleVentas)
                    {
                        var producto = await _context.Productos.FindAsync(detalle.ProductoId);
                        if (producto != null)
                        {
                            detalle.VentaId = id;
                            detalle.PrecioUnitario = producto.Precio;
                            detalle.Subtotal = detalle.Cantidad * detalle.PrecioUnitario;
                            total += detalle.Subtotal;

                            // Actualizar stock
                            producto.Stock -= detalle.Cantidad;
                            _context.Update(producto);
                        }
                    }
                    venta.Total = total;

                    _context.Update(venta);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!VentaExists(venta.VentaId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ClienteId"] = new SelectList(_context.Clientes, "ClienteId", "NombreCompleto", venta.ClienteId);
            ViewData["Productos"] = new SelectList(_context.Productos, "ProductoId", "Nombre");
            return View(venta);
        }

        // GET: Ventas/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var venta = await _context.Ventas
                .Include(v => v.Cliente)
                .Include(v => v.DetalleVentas)
                    .ThenInclude(d => d.Producto)
                .FirstOrDefaultAsync(m => m.VentaId == id);

            if (venta == null)
            {
                return NotFound();
            }

            return View(venta);
        }

        // POST: Ventas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var venta = await _context.Ventas
                .Include(v => v.DetalleVentas)
                .FirstOrDefaultAsync(v => v.VentaId == id);

            if (venta != null)
            {
                // Restaurar stock de productos
                foreach (var detalle in venta.DetalleVentas)
                {
                    var producto = await _context.Productos.FindAsync(detalle.ProductoId);
                    if (producto != null)
                    {
                        producto.Stock += detalle.Cantidad;
                        _context.Update(producto);
                    }
                }

                _context.Ventas.Remove(venta);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        private bool VentaExists(int id)
        {
            return _context.Ventas.Any(e => e.VentaId == id);
        }

        // GET: Ventas/GetProductos
        [HttpGet]
        public async Task<IActionResult> GetProductos()
        {
            var productos = await _context.Productos
                .Select(p => new { productoId = p.ProductoId, nombre = p.Nombre, precio = p.Precio, stock = p.Stock })
                .ToListAsync();
            return Json(productos);
        }
    }
}

