﻿namespace CRUDNativo.Models
{
    public class Producto
    {
        public int ProductoId { get; set; }

        public string Nombre { get; set; }

        public string Descripcion { get; set; }

        public decimal Precio { get; set; }

        public int Stock { get; set; }

        public ICollection<Venta> Ventas { get; set; }
    }
}
